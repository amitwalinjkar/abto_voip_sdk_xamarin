﻿using System;
using Android.App;
using Android.Content;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.OS;

using Android.Support.V4.App;
using System.Collections.Generic;
using Android.Support.V4.Content;
using Android.Content.PM;

using Org.Abtollc.Sdk;
using Org.Abtollc.Utils.Codec;
using Org.Abtollc.Utils;


namespace VoipTest
{
    [Activity(Label = "VoipTest", MainLauncher = true, Icon = "@drawable/icon")]
    public class SplashActivity : Activity, IOnInitializeListener, ActivityCompat.IOnRequestPermissionsResultCallback
    {
        private AbtoPhone abtoPhone;

        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);
			this.RequestWindowFeature(WindowFeatures.NoTitle);

			// Set our view from the "main" layout resource
			SetContentView(Resource.Layout.activity_splash);           

            //Try to initialize phone instance
            if (requestPermissions())  initPhone();
        }
        

        private int REQUEST_CODE_ASK_MULTIPLE_PERMISSIONS = 124;
        List<string> mPermissionsList;

        bool requestPermissions()
        {
            mPermissionsList = new List<string>();
            addPermission(Android.Manifest.Permission.RecordAudio);
            addPermission(Android.Manifest.Permission.Camera);
            addPermission(Android.Manifest.Permission.UseSip);

            if (mPermissionsList.Count > 0)
            {
                ActivityCompat.RequestPermissions(this, mPermissionsList.ToArray(), REQUEST_CODE_ASK_MULTIPLE_PERMISSIONS);
                return false;
            }

            return true;
        }


        private bool addPermission(String permission)
        {
            if (ContextCompat.CheckSelfPermission(this, permission) != Permission.Granted)
            {
                mPermissionsList.Add(permission);
            }

            return true;
        }

                
        public override void OnRequestPermissionsResult(int requestCode, string[] permissions, Permission[] grantResults)
        {
            if (requestCode == REQUEST_CODE_ASK_MULTIPLE_PERMISSIONS)
            {
                int grantedPermissionCounter = 0;
                foreach (Permission p in grantResults)
                {
                    grantedPermissionCounter += (p == Permission.Granted) ? 1 : 0;
                }

                if (grantedPermissionCounter == mPermissionsList.Count)//AllPermisionsGranted
                {
            initPhone();
        }
                else
                {
                    // Permission Denied
                    Toast.MakeText(this, "Some permissions were denied", ToastLength.Short).Show();
                }

            }
            else
            {
                //base.OnRequestPermissionsResult(requestCode, permissions, grantResults);
            }
        }



        protected void initPhone()
        {
            // Get AbtoPhone instance
            abtoPhone = ((AbtoApplication)Application).AbtoPhone;

            if (abtoPhone.IsActive) return;

            abtoPhone.SetInitializeListener(this);

            //configure phone instance
            AbtoPhoneCfg config = abtoPhone.Config;
            //config.setCodecPriority(Codec.G729, (short) 220);
            config.SetCodecPriority(Codec.Pcmu, (short)250);
            //config.setCodecPriority(Codec.GSM, (short) 150);
            //config.setCodecPriority(Codec.PCMA, (short) 240);

            config.SetCodecPriority(Codec.H2631998, (short)220);
            //config.setCodecPriority(Codec.H264, (short) 210);

            //config.STUNEnabled = true;
            //config.STUNServer = "stun.l.google.com:19302";


            config.SetSignallingTransport(AbtoPhoneCfg.SignalingTransportType.Udp);
            //config.setSignallingTransport(AbtoPhoneCfg.SignalingTransportType.TCP);
            //config.setSignallingTransport(AbtoPhoneCfg.SignalingTransportType.TLS);
            //config.setTLSVerifyServer(false);

            config.UseSRTP = false;
			config.UseZRTP = false;
			//config.UserAgent = "my_useragent";


			Log.LogLevel = 5;
            Log.SetUseFile(true);

            // Start initializing
            abtoPhone.Initialize();			

		}


		protected override void OnDestroy()
		{
			abtoPhone.SetInitializeListener(null);
			base.OnDestroy();

		}//onDestroy

		void IOnInitializeListener.OnInitializeState(OnInitializeListenerInitializeState state, string message)
        {
            if ((state == OnInitializeListenerInitializeState.Start) ||
             (state == OnInitializeListenerInitializeState.Info) ||
             (state == OnInitializeListenerInitializeState.Warning) ||
             (state == OnInitializeListenerInitializeState.Fail))
            {
                //set alert for executing the task
               /* AlertDialog.Builder alert = new AlertDialog.Builder(this);
                alert.SetTitle("Error");
                alert.SetMessage(message);
                alert.SetPositiveButton("Ok", (senderAlert, args) => {
                    //change value write your own set of instructions
                    //you can also create an event for the same in xamarin
                    //instead of writing things here                    
                });
               
                //run the alert in UI thread to display in the screen
                RunOnUiThread(() => {
                    alert.Show();
                });
                */
                return;
            }
            

            if (state == OnInitializeListenerInitializeState.Success)
            {
                /*
                Intent intent = new Intent(this, RegisterActivity.class);
                startActivity(intent);
                finish();*/
                AlertDialog.Builder alert = new AlertDialog.Builder(this);
                alert.SetTitle("InitializeState.Success");
                alert.SetMessage(message);
                RunOnUiThread(() => { alert.Show(); });

                StartActivity(typeof(RegisterActivity));

				this.Finish();
			}
        }
    }//public class MainActivity 

}//namespace VoipTest

