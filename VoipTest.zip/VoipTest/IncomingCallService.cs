using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

using Org.Abtollc.Sdk;

namespace VoipTest
{
	[Service]
	class IncomingCallService : Android.App.Service, IOnIncomingCallListener
	{
		private AbtoPhone abtoPhone;

		public override StartCommandResult OnStartCommand(Intent intent, StartCommandFlags flags, int startId)
		{
			abtoPhone = ((AbtoApplication)Application).AbtoPhone;

			abtoPhone.SetIncomingCallListener(this);
			
			return StartCommandResult.Sticky;
		}
		
		public override IBinder OnBind(Intent intent)
		{
			return null;
		}

		public void OnIncomingCall(String remoteContact, long arg1)
		{			
			Intent intent = new Intent(this, typeof(ScreenAV));
			intent.PutExtra("incoming", true);
            intent.PutExtra(ScreenAV.CALL_ID, abtoPhone.ActiveCallId);
            intent.PutExtra(AbtoPhone.RemoteContact, remoteContact);            
			intent.SetFlags(ActivityFlags.NewTask);
			StartActivity(intent);
		}

	}//IncomingCallService

}//VoipTest