using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.Text;

using Org.Abtollc.Sdk;

namespace VoipTest
{
    [Activity(Label = "MainActivity")]
    public class MainActivity : Activity, IOnRegistrationListener
	{
        private String remoteContact;
        private String domain;
        private AbtoPhone abtoPhone;
        private ProgressDialog dialog;

        private Button audioCallButton;
        private Button videoCallButton;
        private EditText callUri;
        private TextView accLabel;
        int accExpire;


        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
			Window.RequestFeature(WindowFeatures.NoTitle);
			SetContentView(Resource.Layout.activity_main);

            // Get AbtoPhone instance
            abtoPhone = ((AbtoApplication)Application).AbtoPhone;

            // Set registration event
            abtoPhone.SetRegistrationStateListener(this);			

			audioCallButton = FindViewById<Button>(Resource.Id.start_audio_call);
            videoCallButton = FindViewById<Button>(Resource.Id.start_video_call);
            callUri = FindViewById<EditText>(Resource.Id.sip_number);

            //callUri.setText("919526072626");
            callUri.Text = "150";

            int accId = (int)abtoPhone.CurrentAccountId;
            accExpire = abtoPhone.Config.GetAccountExpire(accId);


            accLabel = FindViewById<TextView>(Resource.Id.account_label);
            String contact = abtoPhone.Config.GetAccount(accId).AccId;
            contact = contact.Replace("<", "");
            contact = contact.Replace(">", "");

            if (accExpire == 0)
            {
                accLabel.Text = "Local contact: " + contact + ":" + abtoPhone.Config.SipPort;
                callUri.Hint ="number@domain:port";
                domain = "";
            }
            else
            {
                accLabel.Text = "Registered as : " + contact;
                domain = abtoPhone.Config.GetAccountDomain(accId);
            }

            audioCallButton.Click += (object sender, EventArgs e) => { startCall(false); };
            videoCallButton.Click += (object sender, EventArgs e) => { startCall(true);  };
        }

        public void startCall(bool bVideo)
        {
            //Get phone number to dial
            String sipNumber = callUri.Text;
            if (TextUtils.IsEmpty(sipNumber)) return;

            if (TextUtils.IsEmpty(domain))
            {
                if (!sipNumber.Contains("@"))
                {
                    Toast.MakeText(this, "Specify remote side address as 'number@domain:port'", ToastLength.Short).Show();
                    return;
                }
            }

            if (!sipNumber.Contains("sip:")) sipNumber = "sip:" + sipNumber;
            if (!sipNumber.Contains("@")) sipNumber += "@" + domain;


            // Start new call
            try
            {
                if (bVideo) abtoPhone.StartVideoCall(sipNumber, abtoPhone.CurrentAccountId);
                else        abtoPhone.StartCall(sipNumber, abtoPhone.CurrentAccountId);
                            
                remoteContact = sipNumber;

                startAV(false);

            }
            catch (RemoteException e)
            {
                e.PrintStackTrace();
            }
        }

        private void startAV(bool incoming)
        {
            Intent intent = new Intent(this, typeof(ScreenAV));
            intent.PutExtra("incoming", incoming);
            intent.PutExtra(ScreenAV.CALL_ID, abtoPhone.ActiveCallId);
            intent.PutExtra(AbtoPhone.RemoteContact, remoteContact);            
            StartActivity(intent);
        }
               

        public void OnRegistrationFailed(long accId, int statusCode, String statusText)
        {
            if (dialog != null) dialog.Dismiss();

            AlertDialog.Builder fail = new AlertDialog.Builder(this);
            fail.SetTitle("Registration failed");
            fail.SetMessage(statusCode + " - " + statusText);
            RunOnUiThread(() => { fail.Show(); });

            OnUnRegistered(0);
        }

        public void OnRegistered(long accId)
        {
            Toast.MakeText(this, "MainActivity - onRegistered", ToastLength.Short).Show();
        }

        public void OnUnRegistered(long p0)
        {
            if (dialog != null) dialog.Dismiss();

            //Unsubscribe reg events
            abtoPhone.SetRegistrationStateListener(null);			

			//Start reg activity
			StartActivity(typeof(RegisterActivity));

            //Close this activity
            this.Finish();
        }

        public override void OnBackPressed()
        {
            if (accExpire == 0)
            {
                OnUnRegistered(0);
                return;
            }
            try
            {
                if (dialog == null)
                {
                    dialog = new ProgressDialog(this);
                    dialog.SetCancelable(false);                    
                    dialog.SetMessage("Unregistering...");
                }
                dialog.Show();

                abtoPhone.Unregister();
            }
            catch (RemoteException e)
            {
                e.PrintStackTrace();
                dialog.Dismiss();
            }
        }

		//public void OnIncomingCall(String remoteContact, long arg1)
		//{
		//	Intent intent = new Intent(this, typeof(ScreenAV));
		//	intent.PutExtra("incoming", true);
		//	intent.PutExtra(ScreenAV.CALL_ID, abtoPhone.ActiveCallId);
		//	intent.PutExtra(AbtoPhone.RemoteContact, remoteContact);
		//	intent.SetFlags(ActivityFlags.NewTask);
		//	StartActivity(intent);
		//}

	}//MainActivity

}//VoipTest