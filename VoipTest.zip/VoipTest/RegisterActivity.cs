using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

using Org.Abtollc.Sdk;

namespace VoipTest
{
    [Activity(Label = "RegisterActivity")]
    public class RegisterActivity : Activity, IOnRegistrationListener
    {
        private AbtoPhone abtoPhone;
        private ProgressDialog dialog;
        Button regButton;
        EditText userEdit;
        EditText passEdit;
        EditText domainEdit;
        CheckBox disableReg;


        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
			Window.RequestFeature(WindowFeatures.NoTitle);
			SetContentView(Resource.Layout.activity_register);			

			abtoPhone = ((AbtoApplication)Application).AbtoPhone;

            regButton = FindViewById<Button>(Resource.Id.register_button);
            userEdit = FindViewById<EditText>(Resource.Id.login);
            passEdit = FindViewById<EditText>(Resource.Id.password);
            domainEdit = FindViewById<EditText>(Resource.Id.domain);
            disableReg = FindViewById<CheckBox>(Resource.Id.disable_registration);

            userEdit.Text = "103";
            passEdit.Text = "103";
            domainEdit.Text = "172.30.30.150";

            regButton.Click += RegButton_Click;
        }

		protected override void OnResume()
		{
			base.OnResume();
			abtoPhone.SetRegistrationStateListener(this);
		}



		private void RegButton_Click(object sender, EventArgs e)
        {
            //Show progress
            if (dialog == null)
            {
                dialog = new ProgressDialog(this);
                dialog.SetMessage("Registering...");
            }

            dialog.Show();

            int regTimeout = disableReg.Checked ? 0 : 300;
           
			// Add account
            long accId = abtoPhone.Config.AddAccount(domainEdit.Text, null, userEdit.Text, passEdit.Text, null, userEdit.Text, regTimeout, false);

            //Register
            try
            {
                abtoPhone.Register();
            }
            catch (RemoteException ex)
            {
                ex.PrintStackTrace();
            }
        }

        public void OnRegistered(long p0)
        {
            //Hide progress
            if (dialog != null) dialog.Dismiss();

            //Unsubscribe reg events
            abtoPhone.SetRegistrationStateListener(null);

			//Start incoming call service
			StartService(new Intent(this, typeof(IncomingCallService)));

			//Start main activity
			StartActivity(typeof(MainActivity));

			//Close this activity
			this.Finish();
        }

        public void OnRegistrationFailed(long accId, int statusCode, string statusText)
        {
            if (dialog != null) dialog.Dismiss();

            AlertDialog.Builder fail = new AlertDialog.Builder(this);
			fail.SetTitle("Registration failed");
			fail.SetMessage(statusCode + " - " + statusText);
            RunOnUiThread(() => { fail.Show(); });
        }

        public void OnUnRegistered(long p0)
        {
			//Should not happen
            throw new NotImplementedException();
		}


		
		public override void OnBackPressed()
		{
			//Exit app here
			try
			{
				abtoPhone.SetRegistrationStateListener(null);

				//Stop incoming call service
				StopService(new Intent(this, typeof(IncomingCallService)));

				//Destroy phone
				if(abtoPhone.IsActive)        abtoPhone.Destroy();

			} catch (RemoteException ex) {
				ex.PrintStackTrace();
			}
			base.OnBackPressed();
		}


	}//RegisterActivity

}//VoipTest