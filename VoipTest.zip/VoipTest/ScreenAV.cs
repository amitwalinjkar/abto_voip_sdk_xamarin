using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

using Org.Abtollc.Sdk;
using Org.Abtollc.Utils;

namespace VoipTest
{
    [Activity(Label = "ScreenAV")]
    public class ScreenAV : Activity, IOnCallConnectedListener,
        IOnRemoteAlertingListener, IOnCallDisconnectedListener,
        IOnCallHeldListener, IOnToneReceivedListener
	{
        protected static String THIS_FILE = "ScreenAV";
        public static String TOTAL_TIME = "totalTime";
        public static String POINT_TIME = "pointTime";
	    public static String CALL_ID = "call_id";

        private AbtoPhone phone;
        private int activeCallId = AbtoPhone.InvalidCallId;

        private TextView status;
        private TextView name;
        private Button pickUpVideo, speakerBtn, micBtn, hangUpBtn, answerVideoBtn, answerAudioBtn;
        private LinearLayout allVideoLayout;
        private LinearLayout pickUpLayout;
        private static bool sendingVideo;

        private bool bIsIncoming;
        private bool bIsSpeakerOn = false, bIsMicMute = false;

        private int previewRotation = 0, capturerRotation = 0;
        System.Timers.Timer mDurationTimer;



        protected override void OnCreate(Bundle savedInstanceState)
        {   
            base.OnCreate(savedInstanceState);
			this.RequestWindowFeature(WindowFeatures.NoTitle);
			SetContentView(Resource.Layout.screen_caller);			

			phone = ((AbtoApplication)Application).AbtoPhone;
            activeCallId = Intent.GetIntExtra(CALL_ID, AbtoPhone.InvalidCallId);
            Log.D(THIS_FILE, "callId - " + activeCallId);            
            

			name = FindViewById<TextView>(Resource.Id.caller_contact_name);            
            name.Text = Intent.GetStringExtra(AbtoPhone.RemoteContact);
                       
            status = FindViewById<TextView>(Resource.Id.caller_call_status);
            bIsIncoming = Intent.GetBooleanExtra("incoming", false);
            //sendingVideo = getIntent().getBooleanExtra(SEND_VIDEO, false);
            status.Text = bIsIncoming ? "Ringing" : "Calling";

            allVideoLayout = FindViewById<LinearLayout>(Resource.Id.all_video_layout);

            pickUpLayout = FindViewById<LinearLayout>(Resource.Id.caller_pick_up_layout);
            pickUpLayout.Visibility = bIsIncoming ? ViewStates.Visible : ViewStates.Gone;
            

            pickUpVideo = FindViewById<Button>(Resource.Id.caller_pick_up_video_button);
            pickUpVideo.Visibility = phone.IsVideoCall ? ViewStates.Visible : ViewStates.Invisible;

            SurfaceView localVideooutLayout = FindViewById<SurfaceView>(Resource.Id.local_video_parent);
            SurfaceView remoteVideoLayout = FindViewById<SurfaceView>(Resource.Id.remote_video_parent);
            phone.SetVideoWindows(localVideooutLayout, remoteVideoLayout);

		    speakerBtn = FindViewById<Button>(Resource.Id.toggle_speaker_button);
            speakerBtn.Click += (object sender, EventArgs e) =>
            {
                bIsSpeakerOn = !bIsSpeakerOn;

                try
                {
                    phone.SetSpeakerphoneOn(bIsSpeakerOn);
                }
                catch (RemoteException ex)
                {
                    Log.E(THIS_FILE, ex.Message);
                }
            };

    		micBtn= FindViewById<Button>(Resource.Id.toggle_mic_button);
            micBtn.Click += (object sender, EventArgs e) =>
            {
                bIsMicMute = !bIsMicMute;

                try
                {
                    phone.SetMicrophoneMute(bIsMicMute);
                }
                catch (RemoteException ex)
                {
                    Log.E(THIS_FILE, ex.Message);
                }
            };

			hangUpBtn = FindViewById<Button>(Resource.Id.caller_hang_up_button);
			hangUpBtn.Click += HangUpBtn_Click;

			answerVideoBtn = FindViewById<Button>(Resource.Id.caller_pick_up_video_button);
			answerVideoBtn.Click += AnswerVideoBtn_Click;

			answerAudioBtn = FindViewById<Button>(Resource.Id.caller_pick_up_button);
			answerAudioBtn.Click += AnswerAudioBtn_Click;

			
            phone.SetCallConnectedListener(this);
            phone.SetCallDisconnectedListener(this);
            phone.SetOnCallHeldListener(this);
            phone.SetRemoteAlertingListener(this);
            phone.SetToneReceivedListener(this);

		}//OnCreate

		

		public void OnCallConnected(string remoteContact)
        {
            this.pickUpLayout.Visibility = ViewStates.Gone;
            this.pickUpLayout.Visibility = ViewStates.Gone;
            bIsIncoming = false;

            mDurationTimer = new System.Timers.Timer();
            mDurationTimer.Interval = 1000;
            mDurationTimer.Elapsed += new System.Timers.ElapsedEventHandler(t_Elapsed);
            mDurationTimer.Start();
            
            showVideoWindows(phone.IsVideoCall);
        }

        public void OnCallDisconnected(String remoteContact, int callId, int statusCode)
        {
            if (callId == phone.AfterEndedCallId)
            {
                Finish();
                //mTotalTime = 0;
            }
        }

        public void OnCallHeld(OnCallHeldListenerHoldState state)
        {
            if (state == OnCallHeldListenerHoldState.LocalHold) 	status.Text = "Local Hold"; else
		    if (state == OnCallHeldListenerHoldState.RemoteHold)    status.Text = "Remote Hold"; else
		    if (state == OnCallHeldListenerHoldState.Active) 		status.Text = "Active";
        }

        public void OnRemoteAlerting(long accId, int statusCode)
        {
            if (activeCallId == AbtoPhone.InvalidCallId)     activeCallId = phone.ActiveCallId;
                        
            switch (statusCode)
            {
                case OnRemoteAlertingListener.Trying:           status.Text = "Trying"; break;
                case OnRemoteAlertingListener.Ringing:          status.Text = bIsIncoming ? "Ringing" : "Calling";break;
                case OnRemoteAlertingListener.SessionProgress:  status.Text = "Session in progress";     break;
            }
        }

        public void OnToneReceived(char tone)
        {
            Toast.MakeText(this, "DTMF received: " + tone, ToastLength.Short).Show();
        }




		private void HangUpBtn_Click(object sender, EventArgs e)
		{
            try
            {
                if(mDurationTimer != null)  mDurationTimer.Stop();                

                if (phone.BeforeConfirmedCallId == -1)
                {
                    phone.HangUp();
                }
                else
                {
                    phone.RejectCall();
                }
            }
            catch (RemoteException ex)
            {
                Log.E(THIS_FILE, ex.Message);
            }
        }

		private void AnswerAudioBtn_Click(object sender, EventArgs e)
		{
            sendingVideo = false;
            try
            {
                phone.AnswerCall(200, false);
            }
            catch (RemoteException ex)
            {
                Log.E(THIS_FILE, ex.Message);
            }
        }

		private void AnswerVideoBtn_Click(object sender, EventArgs e)
		{
            try
            {
                sendingVideo = true;
                phone.AnswerCall(200, true);                
            }
            catch (RemoteException ex)
            {
                Log.E(THIS_FILE, ex.Message);
            }
        }

        private void showVideoWindows(bool show)
        {
            allVideoLayout.Visibility = show ? ViewStates.Visible : ViewStates.Gone;
        }


        // ==========Timer==============
        //private long mPointTime = 0;
        //private long mTotalTime = 0;
        private Handler mHandler = new Handler();


        public void t_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
        {/*
            mTotalTime += System.currentTimeMillis() - mPointTime;
            mPointTime = System.currentTimeMillis();
            int seconds = (int)(mTotalTime / 1000);
            int minutes = seconds / 60;
            seconds = seconds % 60;

            status.Text = (seconds < 10) ? ("" + minutes + ":0" + seconds) : ("" + minutes + ":" + seconds);
			*/
        }
    
		    
		protected override void OnPause()
		{/*
			if (inCallWakeLock != null && inCallWakeLock.isHeld())
			{
				inCallWakeLock.release();
			}

			mHandler.removeCallbacks(mUpdateTimeTask);*/

			base.OnPause();
		}
		    
		protected override void OnResume()
		{
			pickUpLayout.Visibility = bIsIncoming ? ViewStates.Visible : ViewStates.Gone;

				/*
			if (mTotalTime != 0L)
			{
				mHandler.removeCallbacks(mUpdateTimeTask);
				mHandler.postDelayed(mUpdateTimeTask, 100);
			}

			if (inCallWakeLock != null)
			{
				inCallWakeLock.acquire();
			}*/
			base.OnResume();

			//Restore video after picking up from background
			//if(phone.getActiveCallIdInProgress() != -1){
			//	phone.reinvite();
			//}

		}

		protected override void OnDestroy()
		{
			base.OnDestroy();

			//mHandler.removeCallbacks(mUpdateTimeTask);

			phone.SetCallConnectedListener(null);
			phone.SetCallDisconnectedListener(null);
			phone.SetOnCallHeldListener(null);
			phone.SetRemoteAlertingListener(null);
			phone.SetToneReceivedListener(null);
		}

		
		public override bool OnKeyDown(Keycode keyCode, KeyEvent kevent) 
		{
			if (keyCode == Keycode.Back || keyCode == Keycode.Home)
			{
				try
				{
					phone.HangUp();
				}
				catch (RemoteException ex)
				{
					Log.E(THIS_FILE, ex.Message);
				}
			}
			return base.OnKeyDown(keyCode, kevent);
		}
		
	}//ScreenAV

}//VoipTest