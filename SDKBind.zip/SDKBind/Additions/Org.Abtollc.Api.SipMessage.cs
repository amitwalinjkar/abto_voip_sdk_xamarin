﻿using System;


namespace Org.Abtollc.Api
{

    partial class SipMessage
    {
        public int CompareTo(Java.Lang.Object another)
        {
            return CompareTo((Org.Abtollc.Api.SipMessage)another);
        }
    }
    
   
}